﻿# 🌍 Clima Global Pro

Aplicación de clima en tiempo real con interfaz moderna y datos actualizados.

## 📋 Requisitos
- Python 3.7 o superior
- Conexión a internet

## 🚀 Instalación Rápida

### Opción 1: Instalación Automática (Windows)
1. Ejecuta \instalar_clima.bat\
2. Sigue las instrucciones en pantalla

### Opción 2: Instalación Manual
1. Instala Python desde https://python.org
2. Abre terminal/consola
3. Ejecuta:
\\\
pip install flet requests
\\\
4. Descarga los archivos:
   - \pp_clima_decorado.py\
   - \equirements.txt\

## ▶️ Ejecución
\\\
python app_clima_decorado.py
\\\

## 📦 Archivos Incluidos
- \pp_clima_decorado.py\ - Aplicación principal
- \equirements.txt\ - Dependencias
- \instalar_clima.bat\ - Instalador automático (Windows)

## 🌟 Características
- ✅ Datos en tiempo real
- ✅ Interfaz moderna y responsive
- ✅ Búsqueda por ciudad
- ✅ Información completa del clima
- ✅ Diseño atractivo

## 🔧 Soporte
Si tienes problemas:
1. Verifica que Python esté instalado
2. Asegúrate de tener conexión a internet
3. Ejecuta \pip install flet requests\

¡Disfruta de la aplicación! 🌤️
